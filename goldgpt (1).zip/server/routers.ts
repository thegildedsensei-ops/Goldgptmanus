import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  getConversationMessages,
  createMessage,
  createConversation,
  getUserConversations,
} from "./db";
import { invokeLLM } from "./_core/llm";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  chat: router({
    createConversation: protectedProcedure
      .input(z.object({ title: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const conversation = await createConversation(ctx.user.id, input.title);
        if (!conversation) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create conversation",
          });
        }
        return conversation;
      }),

    getConversations: protectedProcedure.query(async ({ ctx }) => {
      const convos = await getUserConversations(ctx.user.id);
      return convos;
    }),

    getMessages: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ ctx, input }) => {
        const msgs = await getConversationMessages(input.conversationId);
        return msgs;
      }),

    sendMessage: protectedProcedure
      .input(
        z.object({
          conversationId: z.number(),
          content: z.string().min(1),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const userMessage = await createMessage(
          input.conversationId,
          "user",
          input.content
        );

        if (!userMessage) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to save message",
          });
        }

        return {
          userMessage,
        };
      }),

    streamResponse: protectedProcedure
      .input(
        z.object({
          conversationId: z.number(),
          userMessage: z.string(),
          mode: z.enum(["normal", "think", "research"]).default("normal"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        try {
          const conversationMessages = await getConversationMessages(
            input.conversationId
          );

          const messages = conversationMessages.map((msg) => ({
            role: msg.role as "user" | "assistant",
            content: msg.content,
          }));

          let systemPrompt = "You are GoldGPT, a helpful and friendly AI assistant. Provide clear, concise, and helpful responses. Use markdown formatting when appropriate to make your responses more readable.";
          
          if (input.mode === "think") {
            systemPrompt = "You are GoldGPT in Think mode. Provide detailed, thorough, and well-reasoned explanations. Take time to break down complex topics into understandable parts. Use examples and analogies where helpful. Aim for accuracy and depth over brevity.";
          } else if (input.mode === "research") {
            systemPrompt = "You are GoldGPT in Research mode. You have access to current web information. Provide responses based on the latest information available. Include sources and citations when relevant. Be thorough and comprehensive in your research.";
          }

          const response = await invokeLLM({
            messages: [
              {
                role: "system",
                content: systemPrompt,
              },
              ...messages,
            ],
          });

          const rawContent = response.choices[0]?.message?.content;
          let aiContent = "I apologize, but I could not generate a response.";
          
          if (typeof rawContent === "string") {
            aiContent = rawContent;
          } else if (Array.isArray(rawContent)) {
            aiContent = rawContent
              .map((item: any) => (item.type === "text" ? item.text : ""))
              .join("");
          }

          const aiMessage = await createMessage(
            input.conversationId,
            "assistant",
            aiContent
          );

          if (!aiMessage) {
            throw new TRPCError({
              code: "INTERNAL_SERVER_ERROR",
              message: "Failed to save AI response",
            });
          }

          return {
            aiMessage,
            mode: input.mode,
          };
        } catch (error) {
          console.error("LLM Error:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to generate response from AI",
          });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
