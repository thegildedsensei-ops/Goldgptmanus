import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import { getDb, upsertUser } from "./db";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1, openId: string = "test-user-1"): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId,
    email: `sample${userId}@example.com`,
    name: `Sample User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("chat router", () => {
  beforeEach(async () => {
    // Create a test user in the database
    await upsertUser({
      openId: "test-user-1",
      name: "Sample User 1",
      email: "sample1@example.com",
      loginMethod: "manus",
      role: "user",
      lastSignedIn: new Date(),
    });
  });

  it("should create a conversation", async () => {
    const ctx = createAuthContext(1, "test-user-1");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.chat.createConversation({
      title: "Test Conversation",
    });

    expect(result).toBeDefined();
    expect(result?.userId).toBe(ctx.user.id);
    expect(result?.title).toBe("Test Conversation");
  });

  it("should get user conversations", async () => {
    const ctx = createAuthContext(1, "test-user-1");
    const caller = appRouter.createCaller(ctx);

    // Create a conversation first
    const conversation = await caller.chat.createConversation({
      title: "Test Conversation",
    });

    // Get conversations
    const conversations = await caller.chat.getConversations();

    expect(Array.isArray(conversations)).toBe(true);
    expect(conversations.length).toBeGreaterThan(0);
    expect(conversations.some((c) => c.id === conversation?.id)).toBe(true);
  });

  it("should send a message and get it back", async () => {
    const ctx = createAuthContext(1, "test-user-1");
    const caller = appRouter.createCaller(ctx);

    // Create a conversation
    const conversation = await caller.chat.createConversation({
      title: "Test Conversation",
    });

    if (!conversation) {
      throw new Error("Failed to create conversation");
    }

    // Send a message
    const messageResult = await caller.chat.sendMessage({
      conversationId: conversation.id,
      content: "Hello, GoldGPT!",
    });

    expect(messageResult.userMessage).toBeDefined();
    expect(messageResult.userMessage.content).toBe("Hello, GoldGPT!");
    expect(messageResult.userMessage.role).toBe("user");

    // Get messages
    const messages = await caller.chat.getMessages({
      conversationId: conversation.id,
    });

    expect(messages.length).toBeGreaterThan(0);
    expect(messages.some((m) => m.content === "Hello, GoldGPT!")).toBe(true);
  });

  it("should reject empty messages", async () => {
    const ctx = createAuthContext(1, "test-user-1");
    const caller = appRouter.createCaller(ctx);

    const conversation = await caller.chat.createConversation({
      title: "Test Conversation",
    });

    if (!conversation) {
      throw new Error("Failed to create conversation");
    }

    try {
      await caller.chat.sendMessage({
        conversationId: conversation.id,
        content: "",
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("BAD_REQUEST");
    }
  });

  it("should support Think mode", async () => {
    const ctx = createAuthContext(1, "test-user-1");
    const caller = appRouter.createCaller(ctx);

    const conversation = await caller.chat.createConversation({
      title: "Think Mode Test",
    });

    if (!conversation) {
      throw new Error("Failed to create conversation");
    }

    await caller.chat.sendMessage({
      conversationId: conversation.id,
      content: "Explain quantum computing",
    });

    const result = await caller.chat.streamResponse({
      conversationId: conversation.id,
      userMessage: "Explain quantum computing",
      mode: "think",
    });

    expect(result.mode).toBe("think");
    expect(result.aiMessage).toBeDefined();
    expect(result.aiMessage.content.length).toBeGreaterThan(0);
  }, { timeout: 15000 });

  it("should support Research mode", async () => {
    const ctx = createAuthContext(1, "test-user-1");
    const caller = appRouter.createCaller(ctx);

    const conversation = await caller.chat.createConversation({
      title: "Research Mode Test",
    });

    if (!conversation) {
      throw new Error("Failed to create conversation");
    }

    await caller.chat.sendMessage({
      conversationId: conversation.id,
      content: "What are the latest AI developments",
    });

    const result = await caller.chat.streamResponse({
      conversationId: conversation.id,
      userMessage: "What are the latest AI developments",
      mode: "research",
    });

    expect(result.mode).toBe("research");
    expect(result.aiMessage).toBeDefined();
    expect(result.aiMessage.content.length).toBeGreaterThan(0);
  }, { timeout: 15000 });
});
