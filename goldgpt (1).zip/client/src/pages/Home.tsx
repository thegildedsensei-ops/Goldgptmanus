import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Plus, MessageSquare } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  const { data: conversations, isLoading } = trpc.chat.getConversations.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const createConversationMutation = trpc.chat.createConversation.useMutation({
    onSuccess: (data) => {
      utils.chat.getConversations.invalidate();
      setLocation(`/chat/${data.id}`);
    },
  });

  const handleNewConversation = () => {
    createConversationMutation.mutate({
      title: `Conversation ${new Date().toLocaleDateString()}`,
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-card to-muted flex items-center justify-center p-4">
        <Card className="max-w-2xl w-full p-8 md:p-12 bg-white/95 backdrop-blur shadow-2xl">
          <div className="text-center">
            <div className="text-6xl mb-6">✨</div>
            <h1 className="text-4xl md:text-5xl font-bold text-accent mb-4">GoldGPT</h1>
            <p className="text-xl text-foreground mb-2">Your Golden AI Assistant</p>
            <p className="text-muted-foreground mb-8">
              Chat with an intelligent AI powered by cutting-edge language models. Get instant answers,
              creative ideas, and helpful insights.
            </p>

            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3 text-left">
                <div className="w-8 h-8 rounded-full bg-accent text-white flex items-center justify-center font-bold">
                  ✓
                </div>
                <span className="text-foreground">Real-time AI conversations</span>
              </div>
              <div className="flex items-center gap-3 text-left">
                <div className="w-8 h-8 rounded-full bg-accent text-white flex items-center justify-center font-bold">
                  ✓
                </div>
                <span className="text-foreground">Conversation history saved</span>
              </div>
              <div className="flex items-center gap-3 text-left">
                <div className="w-8 h-8 rounded-full bg-accent text-white flex items-center justify-center font-bold">
                  ✓
                </div>
                <span className="text-foreground">Beautiful, intuitive interface</span>
              </div>
            </div>

            <Button
              onClick={() => (window.location.href = getLoginUrl())}
              className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-6 text-lg font-semibold rounded-full"
            >
              Get Started
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-card to-muted">
      {/* Header */}
      <div className="bg-gradient-to-r from-accent to-secondary text-accent-foreground p-6 shadow-lg">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">GoldGPT</h1>
          <p className="text-sm opacity-90">Welcome back, {user?.name || "User"}!</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto p-6">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">Your Conversations</h2>
            <Button
              onClick={handleNewConversation}
              disabled={createConversationMutation.isPending}
              className="bg-accent hover:bg-accent/90 text-accent-foreground gap-2"
            >
              {createConversationMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Plus className="w-4 h-4" />
              )}
              New Conversation
            </Button>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-accent" />
            </div>
          ) : conversations && conversations.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {conversations.map((conversation) => (
                <Card
                  key={conversation.id}
                  onClick={() => setLocation(`/chat/${conversation.id}`)}
                  className="p-4 cursor-pointer hover:shadow-lg transition-shadow bg-white border-2 border-accent/20 hover:border-accent/50"
                >
                  <div className="flex items-start gap-3">
                    <MessageSquare className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-foreground truncate">{conversation.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {new Date(conversation.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center bg-white/80 backdrop-blur">
              <div className="text-4xl mb-4">💬</div>
              <h3 className="text-xl font-semibold text-foreground mb-2">No conversations yet</h3>
              <p className="text-muted-foreground mb-6">
                Start a new conversation to begin chatting with GoldGPT!
              </p>
              <Button
                onClick={handleNewConversation}
                disabled={createConversationMutation.isPending}
                className="bg-accent hover:bg-accent/90 text-accent-foreground gap-2"
              >
                {createConversationMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Plus className="w-4 h-4" />
                )}
                Create First Conversation
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
