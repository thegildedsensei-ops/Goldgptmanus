import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Loader2, Send, Brain, Globe } from "lucide-react";
import { Streamdown } from "streamdown";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useRoute } from "wouter";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  createdAt: Date;
  mode?: "normal" | "think" | "research";
}

export default function Chat() {
  const { user, isAuthenticated } = useAuth();
  const [, params] = useRoute("/chat/:conversationId");
  const conversationId = params?.conversationId ? parseInt(params.conversationId) : null;

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [thinkMode, setThinkMode] = useState(false);
  const [researchMode, setResearchMode] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: messageHistory, isLoading: isLoadingHistory } = trpc.chat.getMessages.useQuery(
    { conversationId: conversationId || 0 },
    { enabled: !!conversationId && isAuthenticated }
  );

  const sendMessageMutation = trpc.chat.sendMessage.useMutation({
    onSuccess: (data) => {
      setMessages((prev) => [
        ...prev,
        { ...data.userMessage, createdAt: new Date(data.userMessage.createdAt) },
      ]);
      setInput("");
      setIsLoading(false);
    },
    onError: () => {
      setIsLoading(false);
    },
  });

  const streamResponseMutation = trpc.chat.streamResponse.useMutation({
    onSuccess: (data) => {
      if (data.aiMessage) {
        setMessages((prev) => [
          ...prev,
          {
            ...data.aiMessage,
            createdAt: new Date(data.aiMessage.createdAt),
            mode: data.mode,
          },
        ]);
      }
      setIsStreaming(false);
    },
    onError: () => {
      setIsStreaming(false);
    },
  });

  useEffect(() => {
    if (messageHistory) {
      setMessages(
        messageHistory.map((msg) => ({
          ...msg,
          createdAt: new Date(msg.createdAt),
        }))
      );
    }
  }, [messageHistory]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || !conversationId || isLoading || isStreaming) return;

    setIsLoading(true);
    setIsStreaming(true);

    try {
      await sendMessageMutation.mutateAsync({
        conversationId,
        content: input,
      });

      const mode = thinkMode ? "think" : researchMode ? "research" : "normal";

      await streamResponseMutation.mutateAsync({
        conversationId,
        userMessage: input,
        mode,
      });
    } catch (error) {
      console.error("Failed to send message:", error);
      setIsLoading(false);
      setIsStreaming(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-background via-card to-muted">
        <Card className="p-8 text-center max-w-md">
          <h1 className="text-2xl font-bold text-accent mb-4">GoldGPT</h1>
          <p className="text-foreground mb-6">Please log in to start chatting with GoldGPT.</p>
        </Card>
      </div>
    );
  }

  if (!conversationId) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-background via-card to-muted">
        <Card className="p-8 text-center max-w-md">
          <h1 className="text-2xl font-bold text-accent mb-4">GoldGPT</h1>
          <p className="text-foreground">Create a new conversation to get started.</p>
        </Card>
      </div>
    );
  }

  if (isLoadingHistory) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-background via-card to-muted">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-background via-card to-muted">
      {/* Header */}
      <div className="bg-gradient-to-r from-accent to-secondary text-accent-foreground p-4 shadow-lg">
        <h1 className="text-2xl font-bold">GoldGPT</h1>
        <p className="text-sm opacity-90">Your Golden AI Assistant</p>
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <Card className="p-8 text-center max-w-md bg-white/80 backdrop-blur">
              <div className="text-4xl mb-4">✨</div>
              <h2 className="text-xl font-semibold text-foreground mb-2">Start a Conversation</h2>
              <p className="text-muted-foreground">
                Ask GoldGPT anything. Use Think mode for deeper reasoning or Research mode to search the web.
              </p>
            </Card>
          </div>
        ) : (
          messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <Card
                className={`max-w-xs lg:max-w-md xl:max-w-lg px-4 py-3 ${
                  message.role === "user"
                    ? "bg-accent text-accent-foreground rounded-3xl rounded-tr-none"
                    : "bg-white text-foreground border-2 border-accent/20 rounded-3xl rounded-tl-none"
                }`}
              >
                {message.mode && message.role === "assistant" && (
                  <div className="flex items-center gap-2 mb-2 text-xs font-semibold text-accent">
                    {message.mode === "think" && (
                      <>
                        <Brain className="w-3 h-3" />
                        <span>Deep Thinking</span>
                      </>
                    )}
                    {message.mode === "research" && (
                      <>
                        <Globe className="w-3 h-3" />
                        <span>Web Research</span>
                      </>
                    )}
                  </div>
                )}
                {message.role === "assistant" ? (
                  <Streamdown>{message.content}</Streamdown>
                ) : (
                  <p className="text-sm">{message.content}</p>
                )}
              </Card>
            </div>
          ))
        )}

        {isStreaming && (
          <div className="flex justify-start">
            <Card className="bg-white text-foreground border-2 border-accent/20 rounded-3xl rounded-tl-none px-4 py-3">
              <div className="flex space-x-2">
                <div className="w-2 h-2 bg-accent rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-accent rounded-full animate-bounce delay-100"></div>
                <div className="w-2 h-2 bg-accent rounded-full animate-bounce delay-200"></div>
              </div>
            </Card>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="bg-white border-t-2 border-accent/20 p-4 shadow-lg">
        <div className="flex gap-2 max-w-4xl mx-auto mb-3">
          <Button
            onClick={() => {
              setThinkMode(!thinkMode);
              setResearchMode(false);
            }}
            variant={thinkMode ? "default" : "outline"}
            className={`gap-2 ${
              thinkMode
                ? "bg-accent hover:bg-accent/90 text-accent-foreground"
                : "border-accent/30 text-foreground hover:bg-accent/10"
            }`}
            disabled={isLoading || isStreaming}
          >
            <Brain className="w-4 h-4" />
            Think
          </Button>
          <Button
            onClick={() => {
              setResearchMode(!researchMode);
              setThinkMode(false);
            }}
            variant={researchMode ? "default" : "outline"}
            className={`gap-2 ${
              researchMode
                ? "bg-accent hover:bg-accent/90 text-accent-foreground"
                : "border-accent/30 text-foreground hover:bg-accent/10"
            }`}
            disabled={isLoading || isStreaming}
          >
            <Globe className="w-4 h-4" />
            Research
          </Button>
        </div>

        <div className="flex gap-2 max-w-4xl mx-auto">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder="Type your message here..."
            disabled={isLoading || isStreaming}
            className="flex-1 border-2 border-accent/30 focus:border-accent bg-background text-foreground placeholder:text-muted-foreground"
          />
          <Button
            onClick={handleSendMessage}
            disabled={!input.trim() || isLoading || isStreaming}
            className="bg-accent hover:bg-accent/90 text-accent-foreground px-6"
          >
            {isLoading || isStreaming ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
