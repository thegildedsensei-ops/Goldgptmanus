# GoldGPT TODO

## Core Features
- [x] Database schema for messages and conversations
- [x] Gold/yellow/white themed chat interface
- [x] Message input field with send functionality
- [x] Message history display with user/AI distinction
- [x] Real-time streaming LLM responses
- [x] Markdown rendering for AI responses
- [x] Message persistence to database
- [x] Conversation history management
- [x] Loading states and error handling
- [x] Unit tests for backend procedures
- [ ] Integration testing for chat flow (manual testing in browser)

## Design & Styling
- [x] Apply gold (#D4AF37), yellow (#FFD700), and white color scheme
- [x] Create responsive chat layout
- [x] Style message bubbles for user vs AI
- [x] Add visual feedback for message sending
- [x] Implement smooth animations for incoming messages

## Backend Setup
- [x] Configure LLM integration with streaming
- [x] Create message save procedure
- [x] Create message fetch procedure
- [x] Implement conversation context management
- [x] Add error handling for API failures

## Testing & Deployment
- [x] Write vitest tests for procedures
- [ ] Test streaming response functionality (manual in browser)
- [x] Verify message persistence
- [ ] Test markdown rendering (manual in browser)
- [ ] Create checkpoint for deployment


## New Features - Think & Research Modes
- [ ] Add Think mode toggle button to chat interface
- [ ] Add Research mode toggle button to chat interface
- [ ] Implement Think mode backend with extended reasoning
- [ ] Implement Research mode backend with web search integration
- [ ] Display research sources in chat responses
- [ ] Add visual indicators for Think/Research modes
- [ ] Test Think mode with complex reasoning tasks
- [ ] Test Research mode with web search queries
